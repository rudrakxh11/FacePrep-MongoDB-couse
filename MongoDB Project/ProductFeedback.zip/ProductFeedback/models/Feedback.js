const mongoose = require("mongoose");

const feedbackSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },

    description: {
      type: String,
      required: true,
    },

    category: {
      type: String,
      enum: [
        "Feature Request",
        "Bug Report",
        "Improvement",
      ],
      required: true,
    },

    status: {
      type: String,
      enum: [
        "Open",
        "Under Review",
        "Planned",
        "In Progress",
        "Completed",
      ],
      default: "Open",
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Feedback", feedbackSchema);