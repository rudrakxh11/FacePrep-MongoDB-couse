const express = require("express");

const router = express.Router();

const {
  createFeedback,
  getAllFeedback,
  getFeedbackById,
  updateFeedback,
  deleteFeedback,
  searchFeedback,
} = require("../controllers/feedbackController");

router.post("/", createFeedback);

router.get("/", getAllFeedback);

router.get("/search", searchFeedback);

router.get("/:id", getFeedbackById);

router.put("/:id", updateFeedback);

router.delete("/:id", deleteFeedback);

module.exports = router;