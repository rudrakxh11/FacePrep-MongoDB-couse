const Feedback = require("../models/Feedback");

// CREATE FEEDBACK
const createFeedback = async (req, res) => {
  try {
    const feedback = await Feedback.create(req.body);

    const populatedFeedback = await Feedback.findById(
      feedback._id
    ).populate("createdBy", "name email");

    res.status(201).json(populatedFeedback);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// GET ALL FEEDBACK
const getAllFeedback = async (req, res) => {
  try {
    const filter = {};

    if (req.query.status) {
      filter.status = req.query.status;
    }

    if (req.query.category) {
      filter.category = req.query.category;
    }

    const feedbacks = await Feedback.find(filter)
      .populate("createdBy", "name email")
      .sort({ createdAt: -1 });

    res.status(200).json(feedbacks);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// GET SINGLE FEEDBACK
const getFeedbackById = async (req, res) => {
  try {
    const feedback = await Feedback.findById(req.params.id)
      .populate("createdBy", "name email");

    if (!feedback) {
      return res.status(404).json({
        message: "Feedback not found",
      });
    }

    res.status(200).json(feedback);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// UPDATE FEEDBACK
const updateFeedback = async (req, res) => {
  try {
    const feedback = await Feedback.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    ).populate("createdBy", "name email");

    res.status(200).json(feedback);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// DELETE FEEDBACK
const deleteFeedback = async (req, res) => {
  try {
    await Feedback.findByIdAndDelete(req.params.id);

    res.status(200).json({
      message: "Feedback deleted successfully",
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// SEARCH FEEDBACK
const searchFeedback = async (req, res) => {
  try {
    const keyword = req.query.keyword;

    const feedbacks = await Feedback.find({
      $or: [
        {
          title: {
            $regex: keyword,
            $options: "i",
          },
        },
        {
          description: {
            $regex: keyword,
            $options: "i",
          },
        },
      ],
    }).populate("createdBy", "name email");

    res.status(200).json(feedbacks);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

module.exports = {
  createFeedback,
  getAllFeedback,
  getFeedbackById,
  updateFeedback,
  deleteFeedback,
  searchFeedback,
};