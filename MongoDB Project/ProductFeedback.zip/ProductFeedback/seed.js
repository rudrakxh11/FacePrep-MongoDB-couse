const mongoose = require("mongoose");
const { faker } = require("@faker-js/faker");
require("dotenv").config();

const User = require("./models/User");
const Feedback = require("./models/Feedback");
const Vote = require("./models/Vote");

mongoose.connect(process.env.MONGO_URI);

const seedDatabase = async () => {
  try {
    console.log("Seeding Started...");

    await User.deleteMany({});
    await Feedback.deleteMany({});
    await Vote.deleteMany({});


    const users = [];

    for (let i = 0; i < 20; i++) {
      users.push({
        name: faker.person.fullName(),
        email: faker.internet.email(),
        role: i === 0 ? "manager" : "user",
      });
    }

    const createdUsers = await User.insertMany(users);

    console.log(`Users Created: ${createdUsers.length}`);

    const categories = [
      "Feature Request",
      "Bug Report",
      "Improvement",
    ];

    const statuses = [
      "Open",
      "Under Review",
      "Planned",
      "In Progress",
      "Completed",
    ];

    const feedbacks = [];

    for (let i = 0; i < 50; i++) {
      feedbacks.push({
        title: faker.company.buzzPhrase(),
        description: faker.lorem.paragraph(),
        category:
          categories[
            Math.floor(Math.random() * categories.length)
          ],
        status:
          statuses[
            Math.floor(Math.random() * statuses.length)
          ],
        createdBy:
          createdUsers[
            Math.floor(Math.random() * createdUsers.length)
          ]._id,
      });
    }

    const createdFeedbacks =
      await Feedback.insertMany(feedbacks);

    console.log(
      `Feedback Created: ${createdFeedbacks.length}`
    );

    const votes = [];

    for (let i = 0; i < 100; i++) {
      votes.push({
        user:
          createdUsers[
            Math.floor(Math.random() * createdUsers.length)
          ]._id,

        feedback:
          createdFeedbacks[
            Math.floor(
              Math.random() * createdFeedbacks.length
            )
          ]._id,
      });
    }

    await Vote.insertMany(votes);

    console.log("Votes Created: 100");

    console.log("Database Seeded Successfully");

    process.exit();
  } catch (error) {
    console.log(error);

    process.exit(1);
  }
};

seedDatabase();