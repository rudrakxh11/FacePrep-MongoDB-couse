const swaggerJsdoc = require("swagger-jsdoc");

const options = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "Product Feedback Analyzer API",
      version: "1.0.0",
      description:
        "API Documentation for Product Feedback Analyzer Backend",
    },

    servers: [
      {
        url: "http://localhost:4000",
      },
    ],

    components: {
      schemas: {
        User: {
          type: "object",
          properties: {
            name: {
              type: "string",
            },
            email: {
              type: "string",
            },
            role: {
              type: "string",
            },
          },
        },

        Feedback: {
          type: "object",
          properties: {
            title: {
              type: "string",
            },
            description: {
              type: "string",
            },
            category: {
              type: "string",
            },
            status: {
              type: "string",
            },
            createdBy: {
              type: "string",
            },
          },
        },

        Vote: {
          type: "object",
          properties: {
            user: {
              type: "string",
            },
            feedback: {
              type: "string",
            },
          },
        },
      },
    },

    paths: {
      "/api/users": {
        post: {
          summary: "Create User",
          requestBody: {
            required: true,
            content: {
              "application/json": {
                schema: {
                  $ref: "#/components/schemas/User",
                },
              },
            },
          },
          responses: {
            201: {
              description: "User Created",
            },
          },
        },

        get: {
          summary: "Get All Users",
          responses: {
            200: {
              description: "List of Users",
            },
          },
        },
      },

      "/api/feedback": {
        post: {
          summary: "Create Feedback",
          requestBody: {
            required: true,
            content: {
              "application/json": {
                schema: {
                  $ref: "#/components/schemas/Feedback",
                },
              },
            },
          },
          responses: {
            201: {
              description: "Feedback Created",
            },
          },
        },

        get: {
          summary: "Get All Feedback",
          responses: {
            200: {
              description: "Feedback List",
            },
          },
        },
      },

      "/api/feedback/search": {
        get: {
          summary: "Search Feedback",
          parameters: [
            {
              name: "keyword",
              in: "query",
              required: true,
              schema: {
                type: "string",
              },
            },
          ],
          responses: {
            200: {
              description: "Search Results",
            },
          },
        },
      },

      "/api/feedback/{id}": {
        get: {
          summary: "Get Feedback By ID",
          parameters: [
            {
              name: "id",
              in: "path",
              required: true,
              schema: {
                type: "string",
              },
            },
          ],
          responses: {
            200: {
              description: "Feedback Found",
            },
          },
        },

        put: {
          summary: "Update Feedback",
          parameters: [
            {
              name: "id",
              in: "path",
              required: true,
              schema: {
                type: "string",
              },
            },
          ],
          responses: {
            200: {
              description: "Feedback Updated",
            },
          },
        },

        delete: {
          summary: "Delete Feedback",
          parameters: [
            {
              name: "id",
              in: "path",
              required: true,
              schema: {
                type: "string",
              },
            },
          ],
          responses: {
            200: {
              description: "Feedback Deleted",
            },
          },
        },
      },

      "/api/votes": {
        post: {
          summary: "Create Vote",
          requestBody: {
            required: true,
            content: {
              "application/json": {
                schema: {
                  $ref: "#/components/schemas/Vote",
                },
              },
            },
          },
          responses: {
            201: {
              description: "Vote Added",
            },
          },
        },

        get: {
          summary: "Get All Votes",
          responses: {
            200: {
              description: "Vote List",
            },
          },
        },
      },

      "/api/analytics/dashboard": {
        get: {
          summary: "Dashboard Analytics",
          responses: {
            200: {
              description: "Dashboard Data",
            },
          },
        },
      },

      "/api/analytics/top-features": {
        get: {
          summary: "Most Requested Features",
          responses: {
            200: {
              description: "Top Features",
            },
          },
        },
      },

      "/api/analytics/categories": {
        get: {
          summary: "Category Analytics",
          responses: {
            200: {
              description: "Category Statistics",
            },
          },
        },
      },

      "/api/analytics/status": {
        get: {
          summary: "Status Analytics",
          responses: {
            200: {
              description: "Status Statistics",
            },
          },
        },
      },

      "/api/analytics/monthly-trends": {
        get: {
          summary: "Monthly Feedback Trends",
          responses: {
            200: {
              description: "Monthly Trends",
            },
          },
        },
      },
    },
  },

  apis: [],
};

module.exports = swaggerJsdoc(options);