const express = require("express");

const router = express.Router();

const {
  mostRequestedFeatures,
  categoryAnalytics,
  statusAnalytics,
  monthlyTrends,
  dashboardSummary,
} = require("../controllers/analyticsController");

router.get("/dashboard", dashboardSummary);

router.get("/top-features", mostRequestedFeatures);

router.get("/categories", categoryAnalytics);

router.get("/status", statusAnalytics);

router.get("/monthly-trends", monthlyTrends);

module.exports = router;