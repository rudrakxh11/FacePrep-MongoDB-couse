const express = require("express");
const dotenv = require("dotenv");
const swaggerUi = require("swagger-ui-express");

const connectDB = require("./config/db");
const swaggerSpecs = require("./docs/swagger");

dotenv.config();

connectDB();

const app = express();

app.use(express.json());

const feedbackRoutes = require("./routes/feedbackRoutes");
const userRoutes = require("./routes/userRoutes");
const voteRoutes = require("./routes/voteRoutes");
const analyticsRoutes = require("./routes/analyticsRoutes");

app.use("/api/users", userRoutes);
app.use("/api/feedback", feedbackRoutes);
app.use("/api/votes", voteRoutes);
app.use("/api/analytics", analyticsRoutes);

app.use(
  "/api-docs",
  swaggerUi.serve,
  swaggerUi.setup(swaggerSpecs)
);

const PORT = process.env.PORT || 4000;

app.listen(PORT, () => {
  console.log(`Server Running on Port ${PORT}`);
});