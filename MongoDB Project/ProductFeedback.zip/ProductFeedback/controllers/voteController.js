const Vote = require("../models/Vote");

// ADD VOTE
const addVote = async (req, res) => {
  try {
    const { user, feedback } = req.body;

    const existingVote = await Vote.findOne({
      user,
      feedback,
    });

    if (existingVote) {
      return res.status(400).json({
        message: "User already voted",
      });
    }

    const vote = await Vote.create({
      user,
      feedback,
    });

    res.status(201).json(vote);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// GET ALL VOTES
const getVotes = async (req, res) => {
  try {
    const votes = await Vote.find()
      .populate("user", "name email")
      .populate("feedback", "title");

    res.status(200).json(votes);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

module.exports = {
  addVote,
  getVotes,
};