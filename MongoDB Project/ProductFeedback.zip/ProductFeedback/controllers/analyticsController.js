const Feedback = require("../models/Feedback");
const Vote = require("../models/Vote");
const User = require("../models/User");

// TOP REQUESTED FEATURES
const mostRequestedFeatures = async (req, res) => {
  try {
    const data = await Vote.aggregate([
      {
        $group: {
          _id: "$feedback",
          totalVotes: {
            $sum: 1,
          },
        },
      },
      {
        $lookup: {
          from: "feedbacks",
          localField: "_id",
          foreignField: "_id",
          as: "feedbackInfo",
        },
      },
      {
        $unwind: "$feedbackInfo",
      },
      {
        $project: {
          _id: 0,
          title: "$feedbackInfo.title",
          category: "$feedbackInfo.category",
          totalVotes: 1,
        },
      },
      {
        $sort: {
          totalVotes: -1,
        },
      },
    ]);

    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// CATEGORY ANALYTICS
const categoryAnalytics = async (req, res) => {
  try {
    const data = await Feedback.aggregate([
      {
        $group: {
          _id: "$category",
          total: {
            $sum: 1,
          },
        },
      },
    ]);

    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// STATUS ANALYTICS
const statusAnalytics = async (req, res) => {
  try {
    const data = await Feedback.aggregate([
      {
        $group: {
          _id: "$status",
          total: {
            $sum: 1,
          },
        },
      },
    ]);

    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// MONTHLY FEEDBACK TRENDS
const monthlyTrends = async (req, res) => {
  try {
    const data = await Feedback.aggregate([
      {
        $group: {
          _id: {
            month: {
              $month: "$createdAt",
            },
            year: {
              $year: "$createdAt",
            },
          },
          total: {
            $sum: 1,
          },
        },
      },
      {
        $sort: {
          "_id.year": 1,
          "_id.month": 1,
        },
      },
    ]);

    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// DASHBOARD SUMMARY
const dashboardSummary = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();

    const totalFeedback = await Feedback.countDocuments();

    const totalVotes = await Vote.countDocuments();

    const openRequests = await Feedback.countDocuments({
      status: "Open",
    });

    const completedRequests = await Feedback.countDocuments({
      status: "Completed",
    });

    res.status(200).json({
      totalUsers,
      totalFeedback,
      totalVotes,
      openRequests,
      completedRequests,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

module.exports = {
  mostRequestedFeatures,
  categoryAnalytics,
  statusAnalytics,
  monthlyTrends,
  dashboardSummary,
};